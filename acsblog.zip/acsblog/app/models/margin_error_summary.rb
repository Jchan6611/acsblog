class Margin_error_summary < ActiveRecord::Base

  self.table_name='margin_error_summary'

end