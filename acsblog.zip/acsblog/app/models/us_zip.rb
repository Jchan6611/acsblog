class Us_zip < ActiveRecord::Base

  self.table_name='us_zip'

end