class WelcomeController < ApplicationController
  
    def index
  
         if params[:state].present?
         
           redirect_to estimates_summaries_path
         end
     end	
	
    def parse_state
      state_form = params['state']
      redirect_to estimates_summaries_path
    end
end
