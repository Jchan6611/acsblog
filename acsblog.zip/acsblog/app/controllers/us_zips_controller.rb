class UsZipsController < ApplicationController

  def index 
    @us_zips = Us_zip.all
      respond_to do |format|
       format.html{}
     end
  end

  def show
   redirect_to redirect_to us_zip_path
  end
end
