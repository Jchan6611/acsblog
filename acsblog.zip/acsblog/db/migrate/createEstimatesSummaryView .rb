class CreateEstimatesSummaryView < ActiveRecord::Migration
  def up
   self.connection.execute %Q( create or replace view estimates_summary as
      select e.fileid as ID, e.filetype, e.sequence, e.chariter, e.stusab, e.logrecno, g.ua, u.state, g.zcta5, g.geoid, g.name
          from e_income_data e
          inner join sf_geography g on e.logrecno = g.logrecno
          left outer join us_zip u on u.zipcode=g.zcta5
          order by u.state;
    )
  end

  def down
    self.connection.execute "drop view if exists estimates_summary"
  end

end